# Birthday Challenge 2027 — version 1.0

Site de quiz avec inscriptions, validation manuelle des paiements Orange Money, 32 questions datées, une réponse par question, calcul de score et classement administrateur.

## Important avant toute utilisation publique

- Cette version **ne réalise aucun transfert Orange Money et ne vérifie pas automatiquement les transactions**. Le participant saisit une référence ; l'organisateur vérifie le paiement dans son application Orange Money avant de valider le compte.
- Ne demandez jamais de code PIN, mot de passe Orange Money ou code OTP.
- Le concours avec frais d'inscription et récompenses peut être soumis à des règles camerounaises (jeux-concours, loteries, protection des consommateurs et données personnelles). Faites vérifier le cadre légal et les autorisations nécessaires avant d'encaisser de l'argent.
- Faites tester le site et sauvegardez la base de données avant le lancement.
- La version actuelle prévoit un départage provisoire par score, puis nombre de réponses, puis ancienneté d'inscription. Il faut publier une règle officielle et équitable de départage avant le jeu.
- Les questions d'actualité 2026 sont sourcées dans les références de la conversation, mais elles doivent être revérifiées avant le lancement en janvier 2027.

## Pré-requis

- Node.js 20 ou supérieur
- Un ordinateur pour installer et démarrer le site
- Un hébergement Node.js avec stockage persistant pour le site public (ne pas utiliser un hébergement qui efface les fichiers SQLite au redémarrage)

## Installation locale

1. Décompressez le ZIP.
2. Ouvrez un terminal dans le dossier du projet.
3. Installez les dépendances :

   ```bash
   npm install
   ```

4. Copiez `.env.example` vers `.env`.
5. Générez un hash sécurisé pour le mot de passe administrateur :

   ```bash
   node -e "const b=require('bcryptjs'); console.log(b.hashSync('VOTRE_MOT_DE_PASSE_LONG_ET_UNIQUE',12))"
   ```

6. Collez le hash dans `ADMIN_PASSWORD_HASH` dans `.env`.
7. Modifiez `SESSION_SECRET` avec une longue valeur aléatoire.
8. Renseignez `ORANGE_MONEY_NUMBER` et `ORANGE_MONEY_NAME`. Utilisez uniquement un numéro de réception que vous contrôlez.
9. Lancez le site :

   ```bash
   npm start
   ```

10. Ouvrez `http://localhost:3000` pour le site et `http://localhost:3000/admin.html` pour l'administration.

## Paramètres `.env`

- `ADMIN_USERNAME` : identifiant administrateur.
- `ADMIN_PASSWORD_HASH` : hash bcrypt, jamais le mot de passe en clair.
- `ORANGE_MONEY_NUMBER` : numéro public de réception.
- `ORANGE_MONEY_NAME` : nom affiché au participant.
- `ENTRY_FEE` : frais, 200 FCFA par défaut.
- `RELEASE_HOUR` : heure d'ouverture de la question, 12 par défaut.
- `SESSION_SECRET` : secret de session.
- En production, définissez `NODE_ENV=production`, utilisez HTTPS et configurez `APP_URL`.

## Parcours administrateur

1. Ouvrez `/admin.html`.
2. Connectez-vous avec `ADMIN_USERNAME` et le mot de passe correspondant au hash.
3. Comparez les références saisies avec les transactions reçues dans Orange Money.
4. Cliquez sur **Valider** uniquement après avoir confirmé le paiement.
5. Le participant peut alors se connecter et répondre.
6. Après clôture, vérifiez les scores et cliquez sur **Publier les 20 gagnants**.

## Sauvegarde

Arrêtez le serveur avant de copier `data/birthday.sqlite`. Sauvegardez également `data/questions.json` et conservez ces fichiers dans un emplacement privé et sécurisé. Ne partagez jamais la base de données publiquement.

## Architecture

- `server.js` : API et logique serveur
- `public/` : interface participant et administration
- `data/questions.json` : les 32 questions et corrigés (fichier serveur, non servi comme fichier public)
- `data/birthday.sqlite` : participants, paiements, réponses et paramètres
- `.env` : secrets et configuration locale (ne jamais publier)

## Limites de cette première version

- Pas d'intégration officielle Orange Money API.
- Pas d'envoi automatique de SMS ou WhatsApp.
- Pas de déploiement ni de nom de domaine inclus.
- Pas de récupération de mot de passe automatisée.
- Le classement public n'est visible qu'après publication par l'administrateur.
- Le nombre de participants n'est pas plafonné dans le code ; il dépendra des ressources de l'hébergement.
