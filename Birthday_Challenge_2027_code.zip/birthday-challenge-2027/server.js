require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "birthday.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 phone TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 payment_ref TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS answers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 question_number INTEGER NOT NULL,
 selected_index INTEGER NOT NULL,
 is_correct INTEGER NOT NULL,
 answered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id, question_number)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);

const questionsPath = path.join(DATA_DIR, "questions.json");
let questions = JSON.parse(fs.readFileSync(questionsPath, "utf8"));
const setting = (key, fallback) => {
 const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
 return row ? row.value : fallback;
};
const setSetting = (key, value) => db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, String(value));
const localDate = () => new Intl.DateTimeFormat("en-CA", {
 timeZone:"Africa/Douala", year:"numeric", month:"2-digit", day:"2-digit"
}).format(new Date());
const localHour = () => Number(new Intl.DateTimeFormat("en-GB", {
 timeZone:"Africa/Douala", hour:"2-digit", hourCycle:"h23"
}).format(new Date()));
const publicQuestion = q => ({ number:q.number, date:q.date, category:q.category, text:q.text, options:q.options });
const isAdmin = (req,res,next) => req.session.role === "admin" ? next() : res.status(401).json({error:"Accès administrateur requis."});
const isPlayer = (req,res,next) => req.session.role === "player" ? next() : res.status(401).json({error:"Connecte-toi pour continuer."});
const startDate = "2027-01-05";
const endDate = "2027-02-05";
const fee = Number(process.env.ENTRY_FEE || 200);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:"20kb"}));
app.use(express.urlencoded({extended:false,limit:"20kb"}));
app.use(session({
 store:new SQLiteStore({db:"sessions.sqlite",dir:DATA_DIR,concurrentDB:true}),
 name:"bc2027.sid",
 secret:process.env.SESSION_SECRET || "DEV_ONLY_CHANGE_THIS_SECRET",
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:1000*60*60*8}
}));
app.use("/api", rateLimit({windowMs:15*60*1000,limit:250,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(path.join(__dirname,"public")));

function clean(v,max=120){ return String(v ?? "").trim().slice(0,max); }
function validPhone(v){ return /^[0-9+ ()-]{8,20}$/.test(v); }
function currentQuestion(){
 const today=localDate();
 if(today<startDate || today>endDate || localHour()<Number(process.env.RELEASE_HOUR||12)) return null;
 return questions.find(q=>q.date===today) || null;
}

app.get("/api/config",(req,res)=>res.json({
 title:"Birthday Challenge 2027",fee,currency:"FCFA",
 paymentNumber:process.env.ORANGE_MONEY_NUMBER||"",
 paymentName:process.env.ORANGE_MONEY_NAME||"",
 startDate,endDate,releaseHour:Number(process.env.RELEASE_HOUR||12),
 closeHour:Number(process.env.CLOSE_HOUR||23),
 resultsPublished:setting("results_published","false")==="true"
}));

app.post("/api/register",rateLimit({windowMs:60*60*1000,limit:8}),async(req,res)=>{
 const first=clean(req.body.firstName,60), last=clean(req.body.lastName,60);
 const phone=clean(req.body.phone,20), password=String(req.body.password||"");
 const ref=clean(req.body.paymentRef,80);
 if(!first||!last||!validPhone(phone)||password.length<10||!ref)
   return res.status(400).json({error:"Remplis tous les champs. Le mot de passe doit contenir au moins 10 caractères."});
 try{
  const hash=await bcrypt.hash(password,12);
  db.prepare("INSERT INTO users(first_name,last_name,phone,password_hash,payment_ref) VALUES(?,?,?,?,?)")
    .run(first,last,phone,hash,ref);
  res.json({message:"Demande reçue. Ton compte sera activé après vérification manuelle du paiement."});
 }catch(e){
  if(String(e.code).startsWith("SQLITE_CONSTRAINT")) return res.status(409).json({error:"Ce numéro ou cette référence de paiement est déjà utilisé."});
  res.status(500).json({error:"Erreur lors de l'inscription."});
 }
});

app.post("/api/login",rateLimit({windowMs:15*60*1000,limit:10}),async(req,res)=>{
 const phone=clean(req.body.phone,20), password=String(req.body.password||"");
 const user=db.prepare("SELECT * FROM users WHERE phone=?").get(phone);
 if(!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Identifiants incorrects."});
 if(user.status!=="approved") return res.status(403).json({error:user.status==="pending"?"Paiement en attente de vérification.":"Compte non autorisé. Contacte l'organisateur."});
 req.session.regenerate(err=>{
  if(err) return res.status(500).json({error:"Impossible d'ouvrir la session."});
  req.session.role="player"; req.session.userId=user.id;
  res.json({message:"Connexion réussie.",firstName:user.first_name});
 });
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({message:"Déconnexion réussie."})));
app.get("/api/me",isPlayer,(req,res)=>{
 const user=db.prepare("SELECT first_name,last_name,phone FROM users WHERE id=?").get(req.session.userId);
 const score=db.prepare("SELECT COUNT(*) AS answered, SUM(is_correct)*5 AS score FROM answers WHERE user_id=?").get(req.session.userId);
 res.json({user,answered:score.answered||0,score:score.score||0});
});
app.get("/api/question/today",isPlayer,(req,res)=>{
 const q=currentQuestion();
 if(!q) return res.json({available:false,message:"La question du jour sera disponible à partir de 12 h (heure du Cameroun), du 5 janvier au 5 février 2027."});
 const existing=db.prepare("SELECT selected_index,is_correct FROM answers WHERE user_id=? AND question_number=?").get(req.session.userId,q.number);
 res.json({available:true,question:publicQuestion(q),alreadyAnswered:!!existing,
  result:existing?{correct:!!existing.is_correct,score:existing.is_correct?5:0}:null});
});
app.post("/api/question/answer",isPlayer,(req,res)=>{
 const q=currentQuestion();
 if(!q) return res.status(403).json({error:"Aucune question n'est actuellement ouverte."});
 const index=Number(req.body.selectedIndex);
 if(!Number.isInteger(index)||index<0||index>3) return res.status(400).json({error:"Choix invalide."});
 try{
  const correct=index===q.correctIndex;
  db.prepare("INSERT INTO answers(user_id,question_number,selected_index,is_correct) VALUES(?,?,?,?)")
   .run(req.session.userId,q.number,index,correct?1:0);
  res.json({message:"Réponse enregistrée. Tu ne peux plus modifier ta réponse.",correct,score:correct?5:0});
 }catch(e){
  if(String(e.code).includes("CONSTRAINT")) return res.status(409).json({error:"Tu as déjà répondu à cette question."});
  res.status(500).json({error:"Impossible d'enregistrer la réponse."});
 }
});
app.get("/api/leaderboard",(req,res)=>{
 if(localDate()<endDate || localHour()<24) {
  // The full ranking stays hidden until the challenge has closed.
  if(localDate()<=endDate) return res.status(403).json({error:"Le classement final sera disponible après la clôture du jeu."});
 }
 if(setting("results_published","false")!=="true") return res.status(403).json({error:"Les résultats n'ont pas encore été publiés."});
 const rows=db.prepare(`SELECT u.first_name,u.last_name,COALESCE(SUM(a.is_correct)*5,0) score,
 COUNT(a.id) answered FROM users u LEFT JOIN answers a ON a.user_id=u.id
 WHERE u.status='approved' GROUP BY u.id ORDER BY score DESC, answered DESC, u.created_at ASC LIMIT 20`).all();
 res.json({winners:rows});
});

app.post("/api/admin/login",rateLimit({windowMs:15*60*1000,limit:8}),async(req,res)=>{
 const username=clean(req.body.username,80), password=String(req.body.password||"");
 const hash=process.env.ADMIN_PASSWORD_HASH||"";
 if(username!==process.env.ADMIN_USERNAME || !hash.startsWith("$2") || !(await bcrypt.compare(password,hash)))
  return res.status(401).json({error:"Identifiants administrateur incorrects. Vérifie le fichier .env."});
 req.session.regenerate(err=>{
  if(err) return res.status(500).json({error:"Impossible d'ouvrir la session."});
  req.session.role="admin"; res.json({message:"Bienvenue dans l'administration."});
 });
});
app.get("/api/admin/overview",isAdmin,(req,res)=>{
 const pending=db.prepare("SELECT id,first_name,last_name,phone,payment_ref,created_at FROM users WHERE status='pending' ORDER BY created_at").all();
 const users=db.prepare("SELECT COUNT(*) n FROM users").get().n;
 const approved=db.prepare("SELECT COUNT(*) n FROM users WHERE status='approved'").get().n;
 const answered=db.prepare("SELECT COUNT(*) n FROM answers").get().n;
 const ranking=db.prepare(`SELECT u.first_name,u.last_name,u.phone,COALESCE(SUM(a.is_correct)*5,0) score,
 COUNT(a.id) answered FROM users u LEFT JOIN answers a ON a.user_id=u.id
 WHERE u.status='approved' GROUP BY u.id ORDER BY score DESC, answered DESC LIMIT 100`).all();
 res.json({pending,users,approved,answered,ranking,resultsPublished:setting("results_published","false")==="true",questions:questions.map(publicQuestion)});
});
app.post("/api/admin/users/:id/approve",isAdmin,(req,res)=>{
 const result=db.prepare("UPDATE users SET status='approved' WHERE id=? AND status='pending'").run(Number(req.params.id));
 if(!result.changes) return res.status(404).json({error:"Demande introuvable ou déjà traitée."});
 res.json({message:"Participant activé."});
});
app.post("/api/admin/users/:id/reject",isAdmin,(req,res)=>{
 const result=db.prepare("UPDATE users SET status='rejected' WHERE id=? AND status='pending'").run(Number(req.params.id));
 if(!result.changes) return res.status(404).json({error:"Demande introuvable ou déjà traitée."});
 res.json({message:"Demande refusée."});
});
app.post("/api/admin/results/publish",isAdmin,(req,res)=>{
 const today=localDate();
 if(today<"2027-02-09") return res.status(400).json({error:"La publication des résultats est prévue à partir du 9 février 2027."});
 setSetting("results_published","true");
 res.json({message:"Le classement des 20 premiers est maintenant public."});
});
app.get("/api/admin/questions",isAdmin,(req,res)=>res.json(questions));
app.put("/api/admin/questions/:number",isAdmin,(req,res)=>{
 const n=Number(req.params.number), q=questions.find(x=>x.number===n);
 if(!q) return res.status(404).json({error:"Question introuvable."});
 if(q.date<=localDate()) return res.status(403).json({error:"Cette question est verrouillée car sa date de publication est arrivée."});
 const text=clean(req.body.text,1200), options=req.body.options;
 const correctIndex=Number(req.body.correctIndex);
 if(!text||!Array.isArray(options)||options.length!==4||options.some(x=>!clean(x,250))||!Number.isInteger(correctIndex)||correctIndex<0||correctIndex>3)
  return res.status(400).json({error:"Il faut une question, quatre choix et une bonne réponse valide."});
 Object.assign(q,{text,options:options.map(x=>clean(x,250)),correctIndex});
 fs.writeFileSync(questionsPath,JSON.stringify(questions,null,2),"utf8");
 res.json({message:"Question mise à jour."});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Birthday Challenge 2027 prêt sur http://localhost:${PORT}`));
